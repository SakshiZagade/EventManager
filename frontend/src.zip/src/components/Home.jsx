import { useState } from "react";
import "./Home.css";
import { useNavigate } from "react-router-dom";
import { FcCalendar } from "react-icons/fc";
import { FaPlus } from "react-icons/fa6";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";

const Home = () => {
  const navigate = useNavigate();
  const [showCalendar, setShowCalendar] = useState(false); // State for calendar visibility
  const [selectedDate, setSelectedDate] = useState(new Date()); // State for selected date

  // Sample event data
  const events = [
    {
      id: 1,
      title: "Tech Conference 2025",
      location: "Pune",
      date: "26/01/2025",
    },
    {
      id: 2,
      title: "Art Expo",
      location: "Katraj",
      date: "10/02/2025",
    },
    {
      id: 3,
      title: "Music Festival",
      location: "Wakad",
      date: "15/03/2025",
    },
  ];

  const handleCalendarClick = () => {
    setShowCalendar(!showCalendar); // Toggle calendar visibility
  };

  const handleDateChange = (date) => {
    setSelectedDate(date);
    console.log("Selected Date:", date);
    setShowCalendar(false); // Hide calendar after selecting a date
  };

  return (
    <div className="body">
      <div className="navbar">
        <h1>Event Information</h1>
        <div className="nav-links">
          <a href="Home">Home</a>
          <a href="Create">Events</a>
          <a href="Update">Contact</a>
        </div>
      </div>
      <div>
        <button className="add" onClick={() => navigate("/create")}>
          Add Event <FaPlus size={20} />
        </button>

        <input type="text" id="tagInput" placeholder="Search Events..." />
        <button className="Calendar" onClick={handleCalendarClick}>
          <FcCalendar size={20} />
        </button>
        <span className="selected-date">
          {selectedDate.toLocaleDateString("en-GB")}
        </span>

        {/* Render calendar conditionally */}
        {showCalendar && (
          <Calendar onChange={handleDateChange} value={selectedDate} />
        )}
      </div>

      {/* Event Cards */}
      <div className="event-cards">
        {events.map((event) => (
          <div className="event-card" key={event.id}>
            <h3>{event.title}</h3>
            <p><strong>Location:</strong> {event.location}</p>
            <p><strong>Date:</strong> {event.date}</p>
            <div className="card-buttons">
              <button
                className="register-btn"
                onClick={() => alert(`Registered for ${event.title}`)}
              >
                Register
              </button>
              <button
                className="view-btn"
                onClick={() => navigate(`/events/${event.id}`)}
              >
                View Event
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Home;
