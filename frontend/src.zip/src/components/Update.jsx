
import React, { useState } from 'react'
import './Update.css'

const Update = () => {

    console.log("in the update")

  return (
    
        <h1>Create Event 🍰</h1>

        

  )
}

export default Update