
import React, { useState } from 'react'
import './Create.css'

const Create = () => {

    console.log("in the create")

  return (
    
        <h1>Create Event 🍰</h1>

        

  )
}

export default Create