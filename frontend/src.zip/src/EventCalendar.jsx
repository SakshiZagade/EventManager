import EventCalendar from "./components/EventCalendar";

function App() {
  return (
    <div className="App">
      <EventCalendar />
    </div>
  );
}

export default App;
